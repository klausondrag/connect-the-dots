package com.reuters.ws.example;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;

import com.reuters.ws.example.util.StringUtils;
import com.reuters.ws.example.util.XMLUtils;

/**
 * Query helper class for building and executing web services queries.
 * 
 * Each set parameter returns a reference to Query, allowing for 
 * method-chaining. Example use:
 * 
 * Document xml = Query.createQuery(Query.Type.ITEMS, token)
 * 		 			   .setParameter("dateRange","2010.06.01.12.58")
 * 		 			   .setParameter("channel","Qxp718")
 * 		 			   .getResult();
 * 
 * @author Michael.Boufford
 */
public final class Query {
	/**
	 * The Type enum provides a mapping between query type and 
	 * associated meta-data.  This implementation includes
	 * the base-urls derived from the Config file. 
	 */
	public enum Type { 
		CHANNEL(Config.CHANNELS_URL.getValue()), 
		ITEMS(Config.ITEMS_URL.getValue()), 
		ITEM(Config.ITEM_URL.getValue()),
		OLR(Config.OLR_URL.getValue());
		
		private final String url;
		
		private Type(final String url) {
			this.url = url;
		}
	}
	
	// Query parameters are stored in this map
	private final List<String> params;
	private final Type type;
	
	/**
	 * Private constructor, since the static factory should
	 * be invoked to get an instance.
	 * 
	 * @param type
	 * @param params
	 */
	private Query(final Type type, final List<String> params) {
		this.type = type;
		this.params = params;
	}
	
	/**
	 * A static factory method for creating a web services query.
	 * Sets the token and initializes the Query object.
	 * 
	 * @param type
	 * @param token
	 * @return Query
	 */
	public static Query createQuery(Type type, String token) {
		Query query = new Query(type, new LinkedList<String>()); 
		query.params.add("token=" + token);
		return query;
	}

	/**
	 * Adds a parameter of type Integer to the resulting query
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	public Query setParameter(String key, Integer value) {
		return setParameter(key, value + "");
	}

	/**
	 * Adds a parameter of type String to the resulting query
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	public Query setParameter(String key, String value) {
		params.add(key + "=" + value);
		return new Query(type, params);
	}
	
	/**
	 * Returns an XML document from web services for the given
	 * type and parameters.
	 * 
	 * @return Document (XML)
	 * @throws Exception
	 */
	public Document getResult() throws Exception {
		// Build the request from the map of parameters
		String request = buildRequest();
		System.out.println("Request: " + request);
		// Gets the response from the rest call
		String response = restCall(request, String.class);
		// Returns the XML response as an XML document
		return XMLUtils.createDocument(response);
	}

	/**
	 * Returns a String representation from web services for the
	 * given type and parameters.
	 * 
	 * @return String (XML)
	 * @throws Exception
	 */
	public String getResultAsString() throws Exception {
		// Build the request from the map of parameters
		String request = buildRequest();
		System.out.println("Request: " + request);
		// Gets the response from the rest call
		return restCall(request, String.class);
	}
	
	/**
	 * Builds the querystring from the type and params map
	 * 
	 * @return String
	 */
	private String buildRequest() {
		StringBuilder requestBuilder = new StringBuilder(type.url + "?");
		String[] tuples = params.toArray(new String[params.size()]);
		
		// Separates the key=value pairs with an ampersand
		requestBuilder.append(StringUtils.join(tuples, "&"));
		return requestBuilder.toString();
	}
	
	/**
	 * Makes a request using Spring's RestTemplate
	 * 
	 * @param <T>
	 * @param request
	 * @param theClass
	 * @return instance of T
	 * @throws RuntimeException
	 * @throws InterruptedException 
	 */
	private static <T> T restCall(String request, Class<T> theClass) throws Exception {
		// NOTE: In the very near future throttling will be implemented
		// to prevent excessive usage.  The specific limits have yet to be
		// definitively determined, though one request per 200ms is a limit
		// being discussed during the EAP.
		Thread.sleep(200);
		return new RestTemplate().getForObject(request, theClass);
	}
}
