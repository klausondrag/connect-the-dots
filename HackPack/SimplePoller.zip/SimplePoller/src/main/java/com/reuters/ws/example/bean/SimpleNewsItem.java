package com.reuters.ws.example.bean;

import java.util.Map;

import com.reuters.ws.example.MediaType;
import com.reuters.ws.example.util.StringUtils;

/**
 * A bean representing an SNI
 * 
 * @author Michael.Boufford
 */
public abstract class SimpleNewsItem extends NewsMLBean {
	protected final MediaType mediaType;

	public SimpleNewsItem(final MediaType mediaType) {
		this.mediaType = mediaType;
	}
	
	/**
	 * Fields used for mapping XML fields to instance fields 
	 */
	public static enum Field {
		ID("id"),
		MEDIA_TYPE("mediaType"),
		HEADLINE("headline");
		
		private final String label;
		
		private Field(String tag) {
			this.label = tag;
		}
		
		public String getValue() {
			return label;
		}
	}
	
	/**
	 * Static factory method for creating SNI instances
	 * 
	 * @param map
	 * @return returns a SimpleNewsItemText if the media type is text or
	 * 			a SimpleNewsItemPicture if the media type is picture
	 */
	public static SimpleNewsItem createSNI(Map<String,String> map) {
		String sniMediaType = map.get(Field.MEDIA_TYPE.label);
		
		if(StringUtils.isEmpty(sniMediaType)) {
			return null;
		} else {
			SimpleNewsItem sni = null;
			
			if(!map.containsKey(Field.MEDIA_TYPE.label) || null == map.get(Field.MEDIA_TYPE.label)) {
				System.err.println("No valid media type found");
			} else {
				String mediaType = map.get(Field.MEDIA_TYPE.label);
	
				if(mediaType.equals(MediaType.TEXT.getValue())) {
					sni = new SimpleNewsItemText();
				} else if(mediaType.equals(MediaType.PICTURES.getValue())) {
					sni = new SimpleNewsItemPicture();
				}
				
				sni.setId(map.get(Field.ID.label));
				sni.setHeadline(map.get(Field.HEADLINE.label));
			}
			
			return sni;
		}
	}
	
	/**
	 * Returns the MediaType
	 * 
	 * @return
	 */
	public MediaType getMediaType() {
		return mediaType;
	}
}
