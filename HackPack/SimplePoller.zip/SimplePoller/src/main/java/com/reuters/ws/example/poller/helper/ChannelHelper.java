package com.reuters.ws.example.poller.helper;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.reuters.ws.example.bean.Channel;
import com.reuters.ws.example.util.XMLUtils;
import com.reuters.ws.example.util.XPathExpressions;

/**
 * Provides helper methods for parsing XML into Channel
 * 
 * @author Michael.Boufford
 */
public final class ChannelHelper {
	private static final String CHANNEL = "channelInformation";
	
	/**
	 * Private constructor to prevent instantiation.
	 * 
	 * This class should only contain static methods used in
	 * a static context.
	 */
	private ChannelHelper() {}
	
	/**
	 * Returns the Set of Channel contained in the given XML Document
	 * 
	 * @param document
	 * @return
	 */
	public static Set<Channel> getChannels(Document document) {
		NodeList rootNode = XMLUtils.getNodes(document, XPathExpressions.GET_ALL_CHANNELS); 
		Set<Channel> channels = new HashSet<Channel>();
		traverse(rootNode, channels);
		return channels;	
	}
	
	/**
	 * Traverses the NodeList and builds the Set of Channel represented
	 * by the NodeList
	 * 
	 * @param rootNode
	 * @param channels
	 */
	private static void traverse(NodeList rootNode, Set<Channel> channels) {
		for(int i=0; i<rootNode.getLength(); i++) {
			Node aNode = rootNode.item(i);
			NodeList children = aNode.getChildNodes();

			if(children.getLength() > 0) {
				if(aNode.getNodeName().equals(CHANNEL) && aNode.getNodeType() == Node.ELEMENT_NODE) {
					Map<String,String> map = new HashMap<String,String>();
					
					for(int j=0; j<children.getLength(); j++) {
						Node child = children.item(j);
						map.put(child.getNodeName(), child.getTextContent());
					}
					
					channels.add(createChannel(map));
				}
				traverse(aNode.getChildNodes(), channels);
			}
		}
	}
	
	/**
	 * Channel mapper
	 * 
	 * @param map
	 * @return
	 */
	private static Channel createChannel(Map<String,String> map) {
		Channel channel = new Channel();
		
		channel.setDescription(map.get(Field.DESCRIPTION.tag));
		channel.setAlias(map.get(Field.ALIAS.tag));
		channel.setLastUpdate(new DateTime(map.get(Field.LAST_UPDATE.tag)));
		channel.setCategory(map.get(Field.CATEGORY.tag));
		
		return channel;
	}
	
	/**
	 * Fields used for mapping XML fields to instance fields 
	 */
	private static enum Field {
		DESCRIPTION("description"),
		ALIAS("alias"),
		LAST_UPDATE("lastUpdate"),
		CATEGORY("category");
		
		private final String tag;
		
		private Field(String tag) {
			this.tag = tag;
		}
	}
}
