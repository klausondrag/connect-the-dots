package com.reuters.ws.example;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;

import com.reuters.ws.example.util.StringUtils;
import com.reuters.ws.example.util.XMLUtils;
import com.reuters.ws.example.util.XPathExpressions;

/**
 * A basic authorization class for retrieving a web services token
 * 
 * @author Michael.Boufford
 */
public final class Authorization {
	// Denotes the maximum number of authorization
	// attempts to be made before throwing
	private static final int MAX_ATTEMPTS = 3;
	
	// Number of authorization attempts
	private static int attempts = 0;

	// This static field contains the authorization token
	// which will be used to authorize Web Services requests
	private static String token = null;
	
	private Authorization() {}
	
	/**
	 * Attempts to retrieve a new token
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String getNewToken() throws Exception{
		authorize();	
		return token;
	}
	
	/**
	 * Attempts to authorize the user
	 * 
	 * @throws Exception
	 */
	private static void authorize() throws Exception {
		System.out.println("Attempting authorization...");
		try {
			token = requestToken();
	
			if(!StringUtils.isEmpty(token)) {
				System.out.println("Authorization successful. Token: " + token);
			}
		} catch(Exception e) {
			attempts++;
			
			if(attempts <= MAX_ATTEMPTS) {
				System.err.println("Attempt " + attempts + ": authorization failed - " + (MAX_ATTEMPTS - attempts) + " remaining.");
				Thread.sleep(2000);		// Sleeping for 2 seconds between attempts
				authorize();			// Re-attempts authorization
			} else {
				attempts = 0;			// Reset the number of attempts to zero
				throw new RuntimeException("Authorization has failed");
			}
		}
	}
	
	/**
	 * Retrieves a valid token that can be used to make Agency web service calls. 
	 * The token will be stored in a private class member.
	 * @throws Exception 
	 */
	private static String requestToken() throws Exception {
		// TODO replace this
		trustAllHttpsCertificates();
		
		// Always verifies the host (since the host is trusted/known)
		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
			@Override public boolean verify(String urlHostName, SSLSession session) {
				return true;
			}
		});
		
		System.out.println("Request for token: " + Config.getLoginURL());
		// Request an authorization token and wait for a response.
		String response = new RestTemplate().getForObject(Config.getLoginURL(), String.class);
		Document document = XMLUtils.createDocument(response);
		
		return XMLUtils.xPathQuery(document, XPathExpressions.GET_AUTH_TOKEN);
	}
	
	/**
	 * Creates a factory for secure socket layer factories which will be used to
	 * create SSL sockets that trust all HTTPS certificates.
	 * 
	 * @throws Exception
	 */
	private static void trustAllHttpsCertificates() throws Exception {
		// Create a trust manager that does not validate certificate chains:
		javax.net.ssl.TrustManager[] trustAllCerts = new javax.net.ssl.TrustManager[1];
		javax.net.ssl.TrustManager tm = new miTM();
		trustAllCerts[0] = tm;
		javax.net.ssl.SSLContext sc = javax.net.ssl.SSLContext
				.getInstance("SSL");
		sc.init(null, trustAllCerts, null);
		javax.net.ssl.HttpsURLConnection.setDefaultSSLSocketFactory(sc
				.getSocketFactory());
	}
	
	/**
	 * TrustManager that validates whether both client and server in a
	 * connection are trusted given certificates provided.
	 * 
	 * miTM (Man in the middle)
	 */
	private static final class miTM implements javax.net.ssl.TrustManager,
			javax.net.ssl.X509TrustManager {
		public void checkClientTrusted(
				java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			return;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * javax.net.ssl.X509TrustManager#checkServerTrusted(java.security.cert
		 * .X509Certificate[], java.lang.String)
		 */
		public void checkServerTrusted(
				java.security.cert.X509Certificate[] certs, String authType)
				throws java.security.cert.CertificateException {
			return;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.net.ssl.X509TrustManager#getAcceptedIssuers()
		 */
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
			return null;
		}
	}
}
