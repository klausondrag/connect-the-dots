package com.reuters.ws.example;

/**
 * Configuration
 * 
 * @author Michael.Boufford
 */
public enum Config {
	USER_ID("HackZurichAPI"),				// Your username as provided by Reuters 
	PASSWORD("8XtQb447"),				// Your password as provided by Reuters
	
	PICTURES_FOLDER("/pictures/"),		// Change this to a writeable dir
	HTML_FOLDER("/html/"),				// Change this to a writeable dir
	
	// ----- PLEASE DO NOT CHANGE ITEMS BELOW ----- //
	HOST("rmb.reuters.com"),
	AUTH_URL("https://commerce.reuters.com/rmd/rest/xml/login"),
	CHANNELS_URL("http://rmb.reuters.com/rmd/rest/xml/channels/"),
	ITEMS_URL("http://rmb.reuters.com/rmd/rest/xml/items"),
	ITEM_URL("http://rmb.reuters.com/rmd/rest/xml/item/"),
	OLR_URL("http://rmb.reuters.com/rmd/rest/xml/olr/"),
	DATE_FORMAT("yyyy.MM.dd.HH.mm"),
	PORT("80");
	
	private final String value;
	
	private Config(final String value) {
		this.value = value;
	}
	
	/**
	 * Returns the login URL for web services
	 * 
	 * @return String
	 */
	public static final String getLoginURL() {
		return AUTH_URL.value + "?username=" + USER_ID.value + "&password="
				+ PASSWORD.value;
	}
	
	/**
	 * Returns the value of the Config instance
	 * 
	 * @return String
	 */
	public final String getValue() {
		return value;
	}

	/**
	 * Returns the value of the enumerated item
	 */
	@Override public String toString() {
		return getValue();
	}
}
