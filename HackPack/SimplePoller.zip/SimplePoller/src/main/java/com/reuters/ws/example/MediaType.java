package com.reuters.ws.example;

/**
 * An enumeration of values for the mediaType parameter
 * 
 * @author Michael.Boufford
 */
public enum MediaType {
	TEXT("T","icls:text"),
	PICTURES("P","icls:picture"),
	VIDEO("V","icls:video"),
	GRAPHICS("G","icls:graphic");
	
	private final String value;
	private final String itemClassQCode;
	
	private MediaType(final String value, final String newsMLMediaType) {
		this.value = value;
		this.itemClassQCode = newsMLMediaType;
	}
	
	public String getValue() {
		return value;
	}
	
	public String getItemClassQCode() {
		return itemClassQCode;
	}
}
