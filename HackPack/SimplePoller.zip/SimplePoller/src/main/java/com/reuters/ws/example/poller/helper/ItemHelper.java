package com.reuters.ws.example.poller.helper;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.reuters.ws.example.bean.Item;
import com.reuters.ws.example.util.XMLUtils;
import com.reuters.ws.example.util.XPathExpressions;

/**
 * Provides helper methods for parsing XML into Item
 * 
 * @author Michael.Boufford
 */
public final class ItemHelper {
	
	private static final String RESULT = "result";
	
	/**
	 * Private constructor to prevent instantiation.
	 * 
	 * This class should only contain static methods used in
	 * a static context.
	 */
	private ItemHelper() {}

	/**
	 * Takes an XML document containing results, and returns a
	 * Set of Item
	 * 
	 * @param document
	 * @return
	 */
	public static Set<Item> getItems(Document document) {
		NodeList rootNode = XMLUtils.getNodes(document, XPathExpressions.GET_ALL_RESULT); 
		Set<Item> items = new HashSet<Item>();
		traverse(rootNode, items);
		return items;	
	}
	
	/**
	 * Traverses the NodeList and builds the Set of Item represented
	 * by the NodeList
	 * 
	 * @param rootNode
	 * @param items
	 */
	private static void traverse(NodeList rootNode, Set<Item> items) {
		for(int i=0; i<rootNode.getLength(); i++) {
			Node aNode = rootNode.item(i);
			NodeList children = aNode.getChildNodes();

			if(children.getLength() > 0) {
				if(aNode.getNodeName().equals(RESULT) && aNode.getNodeType() == Node.ELEMENT_NODE) {
					Map<String,String> map = new HashMap<String,String>();
					
					for(int j=0; j<children.getLength(); j++) {
						Node child = children.item(j);
						map.put(child.getNodeName(), child.getTextContent());
					}
					
					items.add(createItem(map));
				}
				traverse(aNode.getChildNodes(), items);
			}
		}
	}
	
	/**
	 * Item mapper
	 * 
	 * @param map
	 * @return
	 */
	private static Item createItem(Map<String,String> map) {
		Item item = new Item();
		
		item.setId(map.get(Field.ID.tag));
		item.setGuid(map.get(Field.GUID.tag));
		item.setDateCreated(new DateTime(map.get(Field.DATE_CREATED.tag))
								.toDateTime(DateTimeZone.UTC));
		item.setSlug(map.get(Field.SLUG.tag));
		item.setLanguage(map.get(Field.LANGUAGE.tag));
		item.setHeadline(map.get(Field.HEADLINE.tag));
		item.setMediaType(map.get(Field.MEDIA_TYPE.tag));
		item.setGeography(map.get(Field.GEOGRAPHY.tag));
		item.setPreviewUrl(map.get(Field.PREVIEW_URL.tag));
		item.setDimensions(map.get(Field.DIMENSIONS.tag));
		
		if(null != map.get(Field.PRIORITY))
			item.setPriority(new Integer(map.get(Field.PRIORITY)));

		if(null != map.get(Field.SIZE))
			item.setSize(new Long(map.get(Field.SIZE)));
		
		return item;
	}

	/**
	 * Fields used for mapping XML fields to instance fields 
	 */
	private static enum Field {
		ID("id"),
		GUID("guid"),
		VERSION("version"),
		DATE_CREATED("dateCreated"),
		SLUG("slug"),
		LANGUAGE("language"),
		HEADLINE("headline"),
		MEDIA_TYPE("mediaType"),
		PRIORITY("priority"),
		GEOGRAPHY("geography"),
		PREVIEW_URL("previewUrl"),
		SIZE("size"),
		DIMENSIONS("dimensions");
		
		private final String tag;
		
		private Field(String tag) {
			this.tag = tag;
		}
	}
}
