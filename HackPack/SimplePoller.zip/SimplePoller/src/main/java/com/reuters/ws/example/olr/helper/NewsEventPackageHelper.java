package com.reuters.ws.example.olr.helper;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.reuters.ws.example.MediaType;
import com.reuters.ws.example.bean.NewsEventPackage;
import com.reuters.ws.example.bean.SimpleNewsItem;
import com.reuters.ws.example.util.XMLUtils;
import com.reuters.ws.example.util.XPathExpressions;

public class NewsEventPackageHelper {
	
	private static final String SNI = "itemRef";
	private static final String ITEM_ID = "residref";
	private static final String ITEM_CLASS = "itemClass";
	private static final String Q_CODE = "qcode";
	
	private NewsEventPackageHelper() {}
	
	/**
	 * Parses the XML associated with a NEP and fills in the skeletal NEP 
	 * passed in the parameter
	 * 
	 * @param document
	 * @param nep
	 * @return
	 */
	public static NewsEventPackage parse(Document document, NewsEventPackage nep) {
		NodeList rootNode = XMLUtils.getNodes(document, XPathExpressions.PRIMARY_ITEM);
		traverse(rootNode, nep);
		return nep;
	}
	
	/**
	 * Traverses the XML document, pulling out fields/attributes where
	 * necessary
	 * 
	 * @param rootNode
	 * @param nep
	 */
	private static void traverse(NodeList rootNode, NewsEventPackage nep) {
		for(int i=0; i<rootNode.getLength(); i++) {
			Node aNode = rootNode.item(i);
			NodeList children = aNode.getChildNodes();
			
			if(children.getLength() > 0) {
				if(aNode.getNodeName().equals(SNI) && aNode.getNodeType() == Node.ELEMENT_NODE) {
					Map<String,String> map = new HashMap<String,String>();
					Node sniIdNode = aNode.getAttributes().getNamedItem(ITEM_ID);
					map.put("id", sniIdNode.getNodeValue());
					
					for(int j=0; j<children.getLength(); j++) {
						// Grabs fields and related attributes for each SNI
						Node child = children.item(j);
						map.put(child.getNodeName(), child.getTextContent());
						
						// Identifies the media type
						if(child.getNodeName().equals(ITEM_CLASS)) {
							String qCode = child.getAttributes().getNamedItem(Q_CODE).getNodeValue();
							
							if(qCode.equals(MediaType.TEXT.getItemClassQCode())) {
								map.put(SimpleNewsItem.Field.MEDIA_TYPE.getValue(), MediaType.TEXT.getValue());
							} else if(qCode.equals(MediaType.PICTURES.getItemClassQCode())) {
								map.put(SimpleNewsItem.Field.MEDIA_TYPE.getValue(), MediaType.PICTURES.getValue());
							}
						}

						// Creates and adds a skeletal SNI to the NEP
						SimpleNewsItem sni = SimpleNewsItem.createSNI(map); 
						if(null != sni) {
							nep.addSNI(sni);
						}
					}
				} else {
					traverse(aNode.getChildNodes(), nep);
				}
			}
		}
	}
}
