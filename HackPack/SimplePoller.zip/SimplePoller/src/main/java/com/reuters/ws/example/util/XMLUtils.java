package com.reuters.ws.example.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * 
 * @author Michael.Boufford
 */
public final class XMLUtils {
	
	private XMLUtils() {}
	
	/**
	 * Story HTML is not wrapped in CDATA, as a result
	 * special treatment is required to correctly parse 
	 * out the HTML content from the XML.
	 * 
	 * @param body
	 * @return
	 * @throws Exception
	 */
	public static String parseNonCDataHTML(Node body) throws Exception {
		StringWriter writer = new StringWriter();
        Source source = new DOMSource(body);
        Result result = new StreamResult(writer);
        TransformerFactory factory = TransformerFactory.newInstance();
        try {
            Transformer transformer = factory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.transform(source, result);
        } catch (TransformerException e) {
            throw new Exception("Unable to read story html", e);
        }
        String buffer = writer.getBuffer().toString();
        
        return buffer;
	}
	
	/**
	 * Creates a {@link Document} from the given XML.
	 * 
	 * @param xml an xml document encoded in UTF-8
	 * @return a Document
	 * @throws XmlException if there was an error building the Document
	 */
	public static Document createDocument(final String xml) throws Exception {
		try {
			return createDocument(new ByteArrayInputStream(xml.getBytes("utf-8")));
		} catch (UnsupportedEncodingException e) {
			throw new Exception("Error building xml document", e);
		}
	}
	
	/**
	 * Creates a {@link Document} from the given input stream.
	 * 
	 * @param input an input stream
	 * @return a Document
	 * @throws XmlException if there was an error building the Document
	 */
	public static Document createDocument(final InputStream input) throws Exception {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(false);
			DocumentBuilder builder = factory.newDocumentBuilder();
			return builder.parse(input);
		} catch (Exception e) {
			throw new Exception("Error building xml document", e);
		}
	}
	
	/**
	 * Executes and XPath query and returns the result as a String
	 * 
	 * @param document
	 * @param xPathExpression
	 * @return
	 */
	public static String xPathQuery(final Document document, final String xPathExpression) {
		try {
			XPath xpath = XPathFactory.newInstance().newXPath();
			return xpath.evaluate(xPathExpression, document);
		} catch(Exception e) {
			System.err.println(e);
			return null;
		}
	}
	
	/**
	 * Method to return NodeList for the given tag.
	 *
	 * @param file Xml file.
	 * @param xPathExpression Xpath expression to use.
	 *
	 * @return Node list.
	 */
	public static NodeList getNodes(final Document document, final String xPathExpression) {
		try {
			XPath xpath = XPathFactory.newInstance().newXPath();
			return (NodeList) xpath.evaluate(xPathExpression, document, XPathConstants.NODESET);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Evaluates this Xpath in the specified context and returns the result as a
	 * NodeList.
	 * 
	 * @param object
	 *            the starting context
	 * @return a NodeList
	 * @throws XPathExpressionException 
	 * @throws XmlException
	 *             if there is an error evaluating the xpath
	 */
	public static NodeList evaluateNodeList(final XPathExpression xpath, final Object object) throws XPathExpressionException {
		return (NodeList) evaluate(xpath, object, XPathConstants.NODESET);
	}
	
	private static Object evaluate(XPathExpression xpath, Object parent, QName type) throws XPathExpressionException {
		return xpath.evaluate(parent, type);
	}
}
