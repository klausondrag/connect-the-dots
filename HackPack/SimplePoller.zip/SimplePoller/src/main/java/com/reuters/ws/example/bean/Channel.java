package com.reuters.ws.example.bean;

import org.joda.time.DateTime;

/**
 * A simple bean representing basic channel information
 * 
 * @author Michael.Boufford
 */
public class Channel {
	private String description;
	private String alias;
	private DateTime lastUpdate;
	private String category;
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public DateTime getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(DateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	@Override public String toString() {
		return "Channel: " + description;
	}
}
