package com.reuters.ws.example.bean;

import java.util.HashMap;
import java.util.Map;

/**
 * A container for NewsEventPackages. When we refer to an Online Report,
 * this is what we are talking about.  
 * 
 * a.k.a. "SNEP," "OLR
 * 
 * @author Michael.Boufford
 */
public final class SuperNewsEventPackage extends NewsMLBean {
	private final Map<String, NewsEventPackage> packages = new HashMap<String, NewsEventPackage>();
	
	public SuperNewsEventPackage(String id, String headline) {
		this.id = id;
		this.headline = headline;
	}
	
	/**
	 * Adds a NEP to the SNEP
	 * 
	 * @param nep
	 */
	public void addNEP(NewsEventPackage nep) {
		packages.put(nep.getId(), nep);
	}
	
	/**
	 * Removes a NEP from the SNEP
	 * 
	 * @param nep
	 */
	public void removeNEP(NewsEventPackage nep) {
		packages.remove(nep.getId());
	}

	/**
	 * Checks to see if a NEP is part of this SNEP
	 * 
	 * @param nep
	 * @return true if nep is part of this snep, false otherwise
	 */
	public boolean hasNEP(NewsEventPackage nep) {
		return packages.containsKey(nep.getId());
	}
	
	/**
	 * Returns the List of NEPs associated with this SNEP
	 * 
	 * @return
	 */
	public Map<String, NewsEventPackage> getPackages() {
		return packages;
	}
}
