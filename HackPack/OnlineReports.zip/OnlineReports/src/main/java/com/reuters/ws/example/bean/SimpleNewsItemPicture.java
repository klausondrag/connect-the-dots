package com.reuters.ws.example.bean;

import java.util.LinkedList;
import java.util.List;

import com.reuters.ws.example.MediaType;

/**
 * Represents a SimpleNewsItem of type Picture
 * 
 * @author Michael.Boufford
 */
public final class SimpleNewsItemPicture extends SimpleNewsItem {

	private final List<Picture> pictures = new LinkedList<Picture>();
	
	public SimpleNewsItemPicture() {
		super(MediaType.PICTURES);
	}
	
	/**
	 * Adds a Picture to the pictures list
	 * 
	 * @param picture
	 */
	public void addPicture(Picture picture) {
		pictures.add(picture);
	}
	
	/**
	 * Removes a Picture from the pictures list
	 * 
	 * @param picture
	 */
	public void removePicture(Picture picture) {
		pictures.remove(picture);
	}
	
	/**
	 * Returns true if the picture already exists in the list
	 * 
	 * @param picture
	 * @return
	 */
	public boolean hasPicture(Picture picture) {
		return pictures.contains(picture);
	}
	
	/**
	 * Returns the list of pictures
	 * 
	 * @return List of pictures
	 */
	public List<Picture> getPictureURLS() {
		return pictures;
	}
}
