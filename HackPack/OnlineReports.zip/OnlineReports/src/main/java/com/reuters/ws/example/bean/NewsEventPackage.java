package com.reuters.ws.example.bean;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a NewsEventPackage (the container for instances of SimpleNewsItem)
 * 
 * a.k.a "NEP"
 * 
 * @author Michael.Boufford
 */
public final class NewsEventPackage extends NewsMLBean {
	
	private final Map<String, SimpleNewsItem> items = new HashMap<String, SimpleNewsItem>();

	private NewsEventPackage() {}

	/**
	 * Fields used for mapping XML fields to instance fields 
	 */
	private static enum Field {
		ID("id"),
		HEADLINE("headline");
		
		private final String label;
		
		private Field(String tag) {
			this.label = tag;
		}
	}
	
	/**
	 * Static factory for NEPs
	 * 
	 * @param map
	 * @return
	 */
	public static NewsEventPackage createNEP(Map<String,String> map) {
		if(null == map || map.size() == 0) {
			return null;
		}
		
		NewsEventPackage nep = new NewsEventPackage();
		
		nep.setId(map.get(Field.ID.label));
		nep.setHeadline(map.get(Field.HEADLINE.label));
		
		return nep;
	}
	
	/**
	 * Adds a SNI to the NEP
	 * 
	 * @param sni
	 */
	public void addSNI(SimpleNewsItem sni) {
		items.put(sni.getId(), sni);
	}
	
	/**
	 * Removes a SNI from the NEP
	 * 
	 * @param sni
	 */
	public void removeSNI(SimpleNewsItem sni) {
		items.remove(sni);
	}
	
	/**
	 * Checks to see if a SNI is part of this NEP
	 * 
	 * @param sni
	 * @return true if sni is part of this nep, false otherwise
	 */
	public boolean hasSNI(SimpleNewsItem sni) {
		return items.containsKey(sni);
	}
	
	/**
	 * Returns the list of SimpleNewsItems associated
	 * with this NEP
	 * 
	 * @return
	 */
	public Map<String, SimpleNewsItem> getItems() {
		return items;
	}
}