package com.reuters.ws.example.olr.helper;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.reuters.ws.example.bean.Picture;
import com.reuters.ws.example.bean.SimpleNewsItem;
import com.reuters.ws.example.bean.SimpleNewsItemPicture;
import com.reuters.ws.example.bean.SimpleNewsItemText;
import com.reuters.ws.example.util.StringUtils;
import com.reuters.ws.example.util.XMLUtils;
import com.reuters.ws.example.util.XPathExpressions;

public class SimpleNewsItemHelper {
	
	private static final String REMOTE_CONTENT = "remoteContent";
	
	private SimpleNewsItemHelper() {}
	
	/**
	 * Parses the XML associated with an SNI and fills in the skeletal SNI 
	 * passed in the parameter
	 * 
	 * @param document
	 * @param sni
	 * @return A complete SNI
	 */
	public static SimpleNewsItem parse(Document document, SimpleNewsItem sni) {
		NodeList rootNode = XMLUtils.getNodes(document, XPathExpressions.PRIMARY_ITEM);
		
		if(sni instanceof SimpleNewsItemPicture) {
			traversePictureSNI(rootNode, (SimpleNewsItemPicture) sni);
		} else if (sni instanceof SimpleNewsItemText) {
			String xmlFileName = XMLUtils.xPathQuery(document, XPathExpressions.SNI_FILENAME);
			Node htmlBody = XMLUtils.getNodes(document, XPathExpressions.SNI_STORY_HTML).item(0);
			
			try {
				// NOTE: since the HTML is not wrapped in CDATA, it will 
				// be subject to some additional parsing
				String storyHTML = XMLUtils.parseNonCDataHTML(htmlBody);
				SimpleNewsItemText snit = (SimpleNewsItemText) sni;
				// Saves the story HTML as an HTML file in the file system
				snit.save(storyHTML, StringUtils.changeExtension(xmlFileName,"html"));
			} catch(Exception e) {
				System.err.println("Failed to save file: " + StringUtils.changeExtension(xmlFileName,"html"));
				e.printStackTrace();
			}
		}
		
		return sni;
	}
	
	/**
	 * Downloads pictures and populates a bean representing each
	 * picture--then, adds it to the SNI.
	 * 
	 * @param rootNode
	 * @param sni
	 */
	private static void traversePictureSNI(NodeList rootNode, SimpleNewsItemPicture sni) {
		for(int i=0; i<rootNode.getLength(); i++) {
			Node aNode = rootNode.item(i);
			NodeList children = aNode.getChildNodes();
			
			if(children.getLength() > 0) {
				if(aNode.getNodeName().equals(REMOTE_CONTENT) && aNode.getNodeType() == Node.ELEMENT_NODE) {
					Map<String,String> map = new HashMap<String,String>();
					
					// Grabs the attributes from the remote content tag and adds them 
					// to the map of mappable fields
					NamedNodeMap rcAttributes = aNode.getAttributes();
					for(int j=0; j<rcAttributes.getLength(); j++) {
						Node attribute = rcAttributes.item(j);
						map.put(attribute.getNodeName(), attribute.getNodeValue());
					}
					
					// Grabs the filename
					NodeList rcChildren = aNode.getChildNodes();
					for(int j=0; j<rcChildren.getLength(); j++) {
						Node child = rcChildren.item(j);
						
						if(child.getNodeName().equals(Picture.Field.FILENAME.getLabel())) {
							map.put(Picture.Field.FILENAME.getLabel(), child.getTextContent());
							break;
						}
					}
					
					// Creates a new Picture instance and adds it to the SNI
					Picture picture = Picture.createPicture(map);
					if(null != picture) {
						sni.addPicture(picture);
					}
				} else {
					traversePictureSNI(aNode.getChildNodes(), sni);
				}
			}
		}
	}
	
	

}
