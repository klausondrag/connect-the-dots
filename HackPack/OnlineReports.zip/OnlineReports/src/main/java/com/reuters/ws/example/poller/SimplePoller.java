package com.reuters.ws.example.poller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.w3c.dom.Document;

import com.reuters.ws.example.Authorization;
import com.reuters.ws.example.MediaType;
import com.reuters.ws.example.Query;
import com.reuters.ws.example.bean.Channel;
import com.reuters.ws.example.bean.Item;
import com.reuters.ws.example.poller.helper.ChannelHelper;
import com.reuters.ws.example.poller.helper.ItemHelper;
import com.reuters.ws.example.util.StringUtils;

/**
 * This is a simple polling application built using the Reuters Web Services API.  
 * 
 * The program requests authorized channels and retrieves related items.  For
 * demonstration purposes, the program prints out the headlines for 20 channels. 
 * 
 * @author Michael.Boufford
 */
public class SimplePoller {
	// 15 minutes in milliseconds
	private static final int POLLING_INTERVAL_MS = 15 * 60 * 1000;
	// Individual items requests will return no more than 300 items
	private static final int MAX_ITEMS_RETURNED = 300;
	
	/**
	 * NOTE ON CACHING: In order to avoid throttling, items will need to be
	 * cached by your application.  This Map implementation is too simplistic
	 * for use in real-life applications using Reuters Web Services.  A database
	 * table would be an example of an appropriate solution.
	 */
	private static final Map<String, Item> uniqItems = new HashMap<String, Item>();
	
	public static void main(String[] args) {
		System.out.println("Polling started.");
		
		try{
			while(true) {
				// Since tokens are only valid for 24 hours from the time at which
				// they are issued, we request a new authorization token after each
				// polling period.
				String token = Authorization.getNewToken();
				
				// Retrieves all channels for the user
				Set<Channel> channels = getChannels(token);
	
				int counter = 1;
				for(Channel channel : channels) {
					// Set a time window for how far back we'd like to go in our request.
					// Keep in mind that Web Services is based off of editorial filing time,
					// not the time that the file arrives in our system.  We recommend a
					// request window of 1 hour for pictures, text, and graphics, and 
					// a 12-hour period for video.
					DateTime since = new DateTime().toDateTime(DateTimeZone.UTC).minusHours(1);
					// Requests new items for channel
					getNewItems(channel, since, token);

					// Prints out the channel name and all associated items
					System.out.println("Channel Name: " + channel.getDescription());
					for(Item item : uniqItems.values()) {
						if(item.getChannels().containsKey(channel.getAlias())) {
							System.out.println("\tItem Headline: " + item.getHeadline());
						}							
					}
	
					// Only print out 20 channels
					if(20 == counter++) {
						break;
					}
				}

				Thread.sleep(POLLING_INTERVAL_MS);
			}
		} catch(Exception e) {
			System.err.println(e);
		}
	}

	/**
	 * Adds to the Map all items by channel since a given DateTime
	 * 
	 * @param channel
	 * @param since
	 * @param token
	 * @throws Exception
	 */
	public static void getNewItems(Channel channel, DateTime since, String token) throws Exception {
		getNewItems(channel, since, null, token);
	}
	
	/**
	 * Adds to the Map all items by channel between two dates
	 * 
	 * @param channel
	 * @param since
	 * @param until
	 * @param token
	 * @throws Exception
	 */
	public static void getNewItems(Channel channel, DateTime since, DateTime until, String token) throws Exception {
		// Builds an Items query and returns an XML document as the result
		Document document = Query.createQuery(Query.Type.ITEMS, token)
								 .setParameter("channel", channel.getAlias())
								 .setParameter("dateRange", StringUtils.formatDateRange(since, until))
								 // Add a mediaType for each type of media we'd like returned
								 .setParameter("mediaType", MediaType.TEXT.getValue())
								 .setParameter("mediaType", MediaType.GRAPHICS.getValue())
								 .setParameter("mediaType", MediaType.PICTURES.getValue())
								 //.setParameter("mediaType", MediaType.VIDEO.getValue())
								 .getResult();
		
		// Parses the items in the XML document and returns a Set of Item
		Set<Item> items = ItemHelper.getItems(document);
		// If we are returned 300 results, chances are we have an incomplete return
		boolean incompleteResult = (items.size() == MAX_ITEMS_RETURNED);
		// Will keep track of the oldest date returned (if request incomplete)
		DateTime oldestItemDateTime = (incompleteResult) ? new DateTime().toDateTime(DateTimeZone.UTC) : null;
		
		// Saves items while preventing duplicates
		for(Item item: items) {
			// Determines the oldest item returned (if request incomplete)
			if((incompleteResult) && item.getDateCreated().isBefore(oldestItemDateTime)) {
				oldestItemDateTime = item.getDateCreated();
			}
			
			// Saves/updates items in our Map
			if(!uniqItems.containsKey(item.getId())) {
				// Save the item if it is new
				item.addChannel(channel);
				uniqItems.put(item.getId(), item);
			} else {
				// If we already have the item, but it appears on a new channel
				// add that channel to the item's channel list
				Item tmp = uniqItems.get(item.getId());
				if(!tmp.hasChannel(channel)) {
					tmp.addChannel(channel);
				}
			}
		}

		// If we still have more items to fetch, we make a recursive call
		if(incompleteResult) {
			getNewItems(channel, since, oldestItemDateTime, token);
		}
	}
	
	/**
	 * Returns the set of all authorized channels
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Set<Channel> getChannels(String token) throws Exception {
		// Requests all authorized channels
		Document document = Query.createQuery(Query.Type.CHANNEL, token)
								 .getResult();

		return ChannelHelper.getChannels(document);
	}
}
