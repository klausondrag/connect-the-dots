package com.reuters.ws.example.olr;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;

import com.reuters.ws.example.Authorization;
import com.reuters.ws.example.Query;
import com.reuters.ws.example.bean.Channel;
import com.reuters.ws.example.bean.NewsEventPackage;
import com.reuters.ws.example.bean.SimpleNewsItem;
import com.reuters.ws.example.bean.SuperNewsEventPackage;
import com.reuters.ws.example.olr.helper.NewsEventPackageHelper;
import com.reuters.ws.example.olr.helper.SimpleNewsItemHelper;
import com.reuters.ws.example.olr.helper.SuperNewsEventPackageHelper;
import com.reuters.ws.example.poller.helper.ChannelHelper;
import com.reuters.ws.example.util.StringUtils;
import com.reuters.ws.example.util.XMLUtils;
import com.reuters.ws.example.util.XPathExpressions;

/**
 * This is an example of an OLR (OnLine Reports) request for all channels
 * 
 * @author Michael.Boufford
 */
public class OnlineReports {
	/**
	 * NOTE ON CACHING: This Map implementation is too simplistic
	 * for use in real-life applications using Reuters Web Services.  A database
	 * table would be an example of an appropriate solution.
	 */
	private static final Map<String, SuperNewsEventPackage> SNEPS = new HashMap<String, SuperNewsEventPackage>();
	
	public static void main(String[] args) {
		try{
			// Since tokens are only valid for 24 hours from the time at which
			// they are issued, we request a new authorization token after each
			// polling period.
			String token = Authorization.getNewToken();
			
			// Retrieves all channels for the user
			Set<Channel> channels = getOLRChannels(token);

			for(Channel channel : channels) {
				System.out.println("Channel Name: " + channel.getDescription());
				// Retrieve the Online Report (a.k.a SNEP) and save it in the map
				SNEPS.put(channel.getAlias(), getOnlineReport(channel, token));
			}
		} catch(Exception e) {
			System.err.println(e.fillInStackTrace());
		}
	}

	/**
	 * Retrieves a bean representing an Online Report. The structure is a tree.
	 * 
	 * A SNEP has many NEPs, a NEP has many SNIs, an SNI can be of type
	 * SNIPicture or SNIText; SNIText has story HTML, SNIPicture has hrefs
	 * to several versions of the same picture.
	 * 
	 * @param channel
	 * @param token
	 * @return
	 * @throws Exception
	 */
	public static SuperNewsEventPackage getOnlineReport(Channel channel, String token) throws Exception {
		// Requests an Online Report (OLR) for a particular channel 
		// returns XML containing a SNEP reference
		System.out.println("Retrieving OLR for channel: " + channel.getDescription());
		Document snepRef = Query.createQuery(Query.Type.OLR, token)
									.setParameter("channel", channel.getAlias())
									.getResult();
		
		// Retrieves the top level SNEP ID that is necessary for NewsML (SNEP) retrieval
		String snepItemId = XMLUtils.xPathQuery(snepRef, XPathExpressions.GET_SNEP_ID);
		String snepHeadline = XMLUtils.xPathQuery(snepRef, XPathExpressions.GET_SNEP_HEADLINE);

		SuperNewsEventPackage snep = null;
		
		// Sometimes we are returned an empty result: i.e., <results/>
		if(!StringUtils.isEmpty(snepItemId)) {
			// Follow the reference to the actual SNEP
			System.out.println("Retrieving the NewsML for SNEP: " + snepHeadline);
			snep = SuperNewsEventPackageHelper.parse(retrieveItemXML(snepItemId, token), 
					new SuperNewsEventPackage(snepItemId,snepHeadline));

			// Drill down to get the NEPs
			for(NewsEventPackage nep : snep.getPackages().values()) {
				System.out.println("Retrieving the NewsML for NEP: " + nep.getHeadline());
				nep = NewsEventPackageHelper.parse(retrieveItemXML(nep.getId(),token), nep);
				
				// Drill down further to get the SNIs
				for(SimpleNewsItem sni : nep.getItems().values()) {
					System.out.println("Retrieving the NewsML for SNI: " + nep.getHeadline());
					sni = SimpleNewsItemHelper.parse(retrieveItemXML(sni.getId(),token), sni);
				}
			}
		}
		
		return snep;
	}
	
	/**
	 * Makes an Item request for a given id
	 * 
	 * @param id
	 * @param token
	 * @return returns the server response as an XML document
	 * @throws Exception
	 */
	public static Document retrieveItemXML(String id, String token) throws Exception{
		return Query.createQuery(Query.Type.ITEM, token)
				    .setParameter("id", id)
				    .getResult();
	}
	
	/**
	 * Returns the set of all authorized OLR channels
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Set<Channel> getOLRChannels(String token) throws Exception {
		// Requests all authorized channels
		Document document = Query.createQuery(Query.Type.CHANNEL, token)
								 .setParameter("channelCategory", "olr")
								 .getResult();

		return ChannelHelper.getChannels(document);
	}
}
