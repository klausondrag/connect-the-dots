package com.reuters.ws.example.bean;

import java.io.FileOutputStream;

import com.reuters.ws.example.Config;
import com.reuters.ws.example.MediaType;

/**
 * Represents a SimpleNewsItem of type Text
 * 
 * @author Michael.Boufford
 */
public final class SimpleNewsItemText extends SimpleNewsItem {
	
	private String storyHTML;
	private String fileName;
	
	public SimpleNewsItemText() {
		super(MediaType.TEXT);
	}
	
	/**
	 * Saves the storyHTML as an HTML file
	 * 
	 * @throws Exception
	 */
	public void save(String storyHTML, String fileName) throws Exception {
		this.storyHTML = storyHTML;
		this.fileName = fileName;
		
		String target = Config.HTML_FOLDER.getValue() + fileName;
		System.out.println("Attempting to write file to: " + target);
		FileOutputStream fos = new FileOutputStream(target);
		fos.write(storyHTML.getBytes());
		System.out.println("HTML File written successfully.");
		fos.close();
	}
	
	/**
	 * Returns the Story HTML
	 * 
	 * @return
	 */
	public String getStoryHTML() {
		return storyHTML;
	}
	
	/**
	 * Returns the Story filename
	 * 
	 * @return
	 */
	public String getFileName() {
		return fileName;
	}
}
