package com.reuters.ws.example.bean;

import org.joda.time.DateTime;

/**
 * An abstract class whose concrete inheritors represent a limited set
 * of the data contained in NewsML documents of various types
 * 
 * @author Michael.Boufford
 */
public abstract class NewsMLBean {
	protected String id;
	protected String headline;
	protected DateTime dateTime;

	/**
	 * Returns the ID associated with this NewsML item
	 * 
	 * @return String id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Returns the headline associated with this NewsML item
	 * 
	 * @return String headline
	 */
	public String getHeadline() {
		return headline;
	}
	
	/**
	 * Sets the ID 
	 * 
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Sets the headline
	 * 
	 * @param headline
	 */
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	
	/**
	 * Sets the datetime
	 * 
	 * @param dateTime
	 */
	public void setDateTime(DateTime dateTime) {
		this.dateTime = dateTime;
	}
}
