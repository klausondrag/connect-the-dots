package com.reuters.ws.example.olr.helper;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.reuters.ws.example.bean.NewsEventPackage;
import com.reuters.ws.example.bean.SuperNewsEventPackage;
import com.reuters.ws.example.util.XMLUtils;
import com.reuters.ws.example.util.XPathExpressions;

/**
 * Provides helper methods for parsing XML into SuperNewsEventPackages
 * 
 * @author Michael.Boufford
 */
public final class SuperNewsEventPackageHelper {

	private static final String NEP = "itemRef";
	private static final String ITEM_ID = "residref";
	
	private SuperNewsEventPackageHelper() {}
	
	/**
	 * Takes an XML document containing a SNEP (i.e., Online Report) and returns
	 * the SNEP.
	 * 
	 * @param document
	 * @return
	 */
	public static SuperNewsEventPackage parse(Document document, SuperNewsEventPackage snep) {
		NodeList rootNode = XMLUtils.getNodes(document, XPathExpressions.PRIMARY_ITEM);
		traverse(rootNode, snep);
		return snep;
	}
	
	/**
	 * Traverse the NodeList, creates NEP instances and adds them to the SNEP
	 * 
	 * @param rootNode
	 * @param snep
	 */
	private static void traverse(NodeList rootNode, SuperNewsEventPackage snep) {
		for(int i=0; i<rootNode.getLength(); i++) {
			Node aNode = rootNode.item(i);
			NodeList children = aNode.getChildNodes();
			
			if(children.getLength() > 0) {
				if(aNode.getNodeName().equals(NEP) && aNode.getNodeType() == Node.ELEMENT_NODE) {
					Map<String,String> map = new HashMap<String,String>();
					Node nepIdNode = aNode.getAttributes().getNamedItem(ITEM_ID);
					map.put("id", nepIdNode.getNodeValue());
					
					// Grabs fields and related attributes for each NEP
					for(int j=0; j<children.getLength(); j++) {
						Node child = children.item(j);
						map.put(child.getNodeName(), child.getTextContent());
					}
					
					// Creates and adds a skeletal NEP to the SNEP
					NewsEventPackage nep = NewsEventPackage.createNEP(map);
					if(null != nep) {
						snep.addNEP(nep);
					}
				} else {
					traverse(aNode.getChildNodes(), snep);
				}
			}
		}
	}
}
