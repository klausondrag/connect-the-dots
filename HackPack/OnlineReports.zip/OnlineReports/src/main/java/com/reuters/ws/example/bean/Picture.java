package com.reuters.ws.example.bean;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.Map;

import com.reuters.ws.example.Authorization;
import com.reuters.ws.example.Config;
import com.reuters.ws.example.util.StringUtils;

public class Picture {
	private static final int MAX_ATTEMPTS = 3;
	private int attempts = 0;
	private boolean downloaded = false;
	
	private String id;
	private String filename;
	private String href;
	private String format;
	private String contentType;
	private String rendition;
	private double size;
	private int width;
	private int height;

	private Picture() {}
	
	/**
	 * Fields used for mapping XML fields to instance fields 
	 */
	public static enum Field {
		ID("residref"),
		HREF("href"),
		FILENAME("rtr:altId"),
		FORMAT("format"),
		CONTENT_TYPE("contenttype"),
		RENDITION("rendition"),
		SIZE("size"),
		WIDTH("width"),
		HEIGHT("height");
		
		private final String label;
		
		private Field(String label) {
			this.label = label;
		}
		
		public String getLabel() {
			return label;
		}
	}
	
	/**
	 * A static factory which creates the Picture instance,
	 * downloads, and saves the file to disk.
	 * 
	 * @param map
	 * @return
	 */
	public static Picture createPicture(Map<String,String> map){
		if(null == map || map.size() == 0) {
			System.err.println("Empty map provided, failed to create picture.");
			return null;
		}
		
		Picture picture = new Picture();
		
		picture.id = map.get(Field.ID.label);
		picture.filename = map.get(Field.FILENAME.label);
		picture.href = map.get(Field.HREF.label);
		picture.format = map.get(Field.FORMAT.label);
		picture.contentType = map.get(Field.CONTENT_TYPE.label);
		picture.rendition = map.get(Field.RENDITION.label);
		picture.size = Double.parseDouble(map.get(Field.SIZE.label));
		picture.width = Integer.parseInt(map.get(Field.WIDTH.label));
		picture.height = Integer.parseInt(map.get(Field.HEIGHT.label));
		
		System.out.println("New image created: \n" + picture);
		
		try {
			picture.download(Config.PICTURES_FOLDER.getValue());
		} catch (Exception e) {
			System.err.println("Download failed...");
			e.printStackTrace();
		}
		
		return picture;
	}

	/**
	 * Attempts to download and save the picture
	 * 
	 * @param target
	 * @throws Exception
	 */
	public void download(String target) throws Exception {
		if(!downloaded && !StringUtils.isEmpty(target)) {
			try {
				System.out.println("Downloading picture from: " + href);
				URL url = new URL(href + "?token=" + Authorization.getNewToken());
				ReadableByteChannel rbc = Channels.newChannel(url.openStream());
				System.out.println("Attempting to write file to: " + target + filename);
				FileOutputStream fos = new FileOutputStream(target + filename);
				fos.getChannel().transferFrom(rbc, 0, 1 << 24);
				fos.close();
				downloaded = true;
				System.out.println("Picture file downloaded and written successfully");
			}catch (IOException e) {
				if(attempts++ < MAX_ATTEMPTS) {
					Thread.sleep(1000);
					download(target);
				} else {
					throw e;
				}
			}
		}
	}
	
	public String getHref() {
		return href;
	}

	public String getFormat() {
		return format;
	}

	public String getContentType() {
		return contentType;
	}

	public String getRendition() {
		return rendition;
	}

	public double getSize() {
		return size;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public String getId() {
		return id;
	}
	
	@Override public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append("\tid: " + id + "\n")
				  .append("\tfilename: " + filename + "\n")
				  .append("\thref: " + href + "\n")
				  .append("\tformat: " + format + "\n")
				  .append("\tcontentType: " + contentType + "\n")
				  .append("\trendition: " + rendition + "\n")
				  .append("\tsize: " + size + "\n")
				  .append("\twidth: " + width + "\n")
				  .append("\theight: " + height);
		
		return strBuilder.toString();
	}
}
