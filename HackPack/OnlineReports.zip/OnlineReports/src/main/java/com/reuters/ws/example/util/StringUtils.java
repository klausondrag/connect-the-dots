package com.reuters.ws.example.util;

import static com.reuters.ws.example.Config.DATE_FORMAT;

import org.joda.time.DateTime;

/**
 * A set of useful String utility functions
 * 
 * @author Michael.Boufford
 */
public final class StringUtils {
	/**
	 * Private constructor to prevent instantiation.
	 * 
	 * This class should only contain static methods used in
	 * a static context.
	 */
	private StringUtils() {}
	
    /**
     * A function to join a string array using a delimiter. 
     *
     * @param strArray Input array to concatenate
     * @param delimiter Delimiter to use.
     * @return String 
     */
    public static String join(final String[] strArray, final String delimiter) {
        if (isEmpty(strArray)) {
            return "";
        }
        StringBuilder ret = new StringBuilder();
        
        // Flag to avoid having the delimiter appear at the front.
        boolean flag = false;
        for (String str : strArray) {
            if (flag) {
                ret.append(delimiter);
            }
            ret.append(str);
            flag = true;
        }
        return ret.toString();
    }
    
    /**
     * Swaps the original file extension for a new extension
     * 
     * Takes a file extension without a '.'
     * 
     * e.g., "html" instead of ".html"
     * 
     * @param original
     * @param desiredExt
     * @return
     */
	public static String changeExtension(String original, String desiredExt) {
		return original.substring(0, original.lastIndexOf('.') + 1) + desiredExt;
	}
    
    /**
     * Method to check if the given string array is empty.
     *
     * @param strArray String array to check.
     * @return True if the array is null or of zero length.
     */
    public static boolean isEmpty(final String[] strArray) {
        return strArray == null || strArray.length == 0;
    }

	/**
	 * Method to check if a given string is empty.
	 *
	 * @param str String to check.
	 *
	 * @return True if the string is blank or null. False otherwise.
	 */
	public static boolean isEmpty(final String str) {
		return str == null || str.trim().equals("");
	}
	
	/**
	 * Formats a date range in the correct format for webservices
	 * 
	 * @param since
	 * @param until
	 * @return String in the format yyyy.MM.dd.HH.mm-yyyy.MM.dd.HH.mm
	 */
	public static String formatDateRange(DateTime since, DateTime until) {
		String dateRange = since.toString(DATE_FORMAT.getValue());
		
		if(null != until) {
			dateRange += "-" + until.toString(DATE_FORMAT.getValue());
		}
		
		return dateRange;
	}
}
