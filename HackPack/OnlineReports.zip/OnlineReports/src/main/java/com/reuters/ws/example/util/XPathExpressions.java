package com.reuters.ws.example.util;

public final class XPathExpressions {
	// Authorization
	public static final String GET_AUTH_TOKEN = "/authToken/text()";
	
	// Channel/Items
	public static final String GET_ALL_CHANNELS = "/availableChannels//*";
	public static final String GET_ALL_RESULT = "/results//*";

	// OLR
	public static final String GET_MEDIA_TYPE = "/newsMessage/itemSet/*[self::packageItem or self::newsItem]/itemMeta/signal[starts-with(@qcode, 'pmt:')]/@qcode";
	public static final String GET_SNEP_ID = "/results/result/id/text()";
	public static final String GET_SNEP_HEADLINE = "/results/result/headline/text()";
	public static final String PRIMARY_ITEM = "/newsMessage/itemSet/*[1]";
	public static final String SNI_VERSION_CREATED = "itemMeta/versionCreated/text()";
	public static final String SNI_STORY_HTML = "/newsMessage/itemSet/newsItem/contentSet/inlineXML/*";
	public static final String SNI_FILENAME = "/newsMessage/itemSet/newsItem/itemMeta/fileName/text()";
}
